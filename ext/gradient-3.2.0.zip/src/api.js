// Загрузка данных из API Электронного дневника СПб.
// Работает и в фоне расширения, и на странице дневника: в обоих случаях запросы идут с cookie входа.

const PMG_ORIGIN = 'https://dnevnik2.petersburgedu.ru';
const PMG_API = PMG_ORIGIN + '/api/';

function pmgQuery(params) {
  const parts = [];
  for (const [k, v] of Object.entries(params || {})) {
    if (v == null) continue;
    if (Array.isArray(v)) v.forEach((x) => parts.push(encodeURIComponent(k + '[]') + '=' + encodeURIComponent(x)));
    else parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(v));
  }
  return parts.join('&');
}

async function pmgGet(path, params) {
  const res = await fetch(PMG_API + path + '?' + pmgQuery(params), {
    credentials: 'include',
    headers: { Accept: 'application/json, text/plain, */*', 'X-Requested-With': 'XMLHttpRequest' }
  });
  if (res.status === 401 || res.status === 403) throw new Error('auth');
  if (!res.ok) throw new Error('Сервер дневника ответил ' + res.status + ' на ' + path);
  // Без входа сайт может вернуть страницу логина вместо данных
  if (!/json/i.test(res.headers.get('content-type') || '') || res.redirected && /login|auth/i.test(res.url)) throw new Error('auth');
  const j = await res.json();
  return j.data;
}

// Собирает все страницы списка.
async function pmgGetAll(path, params) {
  const items = [];
  for (let page = 1; page <= 40; page++) {
    const data = await pmgGet(path, { ...params, p_page: page });
    if (!data || !data.items) break;
    items.push(...data.items);
    if (!data.total_pages || page >= data.total_pages) break;
  }
  return items;
}

async function pmgLoadStudents() {
  let list = [];
  try { list = await pmgGetAll('journal/person/related-child-list', {}); } catch (e) { if (e.message === 'auth') throw e; }
  if (!list.length) {
    try { list = await pmgGetAll('journal/person/related-person-list', {}); } catch (e) { if (e.message === 'auth') throw e; }
  }
  return list.filter((p) => p.educations && p.educations.length).map((p) => {
    const ed = p.educations.find((e) => e.is_active !== false) || p.educations[0];
    return {
      id: p.identity && p.identity.id,
      name: [p.firstname, p.surname].filter(Boolean).join(' '),
      educationId: ed.education_id, groupId: ed.group_id, groupName: ed.group_name, school: ed.institution_name
    };
  });
}

// Всё, что нужно помогатору, одним объектом.
async function pmgLoadAll(studentId) {
  const students = await pmgLoadStudents();
  if (!students.length) throw new Error('В дневнике не нашлось ни одного ученика для этого входа.');
  const st = students.find((s) => s.id === studentId) || students[0];
  const edu = [st.educationId];

  const periodItems = await pmgGetAll('group/group/get-list-period', { p_group_ids: [st.groupId] });
  const periods = pmgNormPeriods(periodItems);
  const year = periods.find((p) => p.kind === 'year') || {
    from: periods.length ? periods[0].from : new Date(new Date().getFullYear(), 8, 1),
    to: periods.length ? periods[periods.length - 1].to : new Date()
  };

  const now = new Date();
  const dayMs = 86400000;
  const hwFrom = new Date(now.getTime() - 21 * dayMs), hwTo = new Date(now.getTime() + 28 * dayMs);

  const [estimates, history, subjects, lessons] = await Promise.all([
    pmgGetAll('journal/estimate/table', { p_educations: edu, p_date_from: pmgFmtDate(year.from), p_date_to: pmgFmtDate(year.to), p_limit: 100 }),
    // Итоговые за все годы (четвертные, годовые, экзамены)
    pmgGetAll('journal/estimate/table', { p_educations: edu, p_limit: 100, p_estimate_types: [23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35] }).catch(() => []),
    pmgGetAll('journal/subject/list-studied', { p_groups: [st.groupId] }).catch(() => []),
    pmgGetAll('journal/lesson/list-by-education', {
      p_datetime_from: pmgFmtDate(hwFrom) + ' 00:00:00', p_datetime_to: pmgFmtDate(hwTo) + ' 23:59:59', p_educations: edu
    }).catch(() => [])
  ]);

  const split = pmgSplitEstimates(estimates);
  const histSplit = pmgSplitEstimates(history);

  return {
    loadedAt: Date.now(),
    student: st,
    students: students.map((s) => ({ id: s.id, name: s.name, groupName: s.groupName })),
    periods: periods.map((p) => ({ ...p, from: p.from.getTime(), to: p.to.getTime() })),
    subjects: subjects.map((s) => ({ id: s.id, name: s.name })),
    marks: split.marks,
    finals: histSplit.finals.length ? histSplit.finals : split.finals,
    absences: split.absences,
    notes: split.notes,
    lessons: lessons.map((l) => ({
      id: l.identity && l.identity.id,
      number: l.number,
      from: l.datetime_from, to: l.datetime_to,
      subjectId: l.subject_id, subject: l.subject_name,
      topic: l.content_name || '',
      tasks: (l.tasks || []).filter((t) => t.task_kind_code === 'homework' || !t.task_kind_code).map((t) => ({
        text: (t.task_name || '').trim(),
        files: (t.files || []).map((f) => f.file_name)
      })).filter((t) => t.text.replace(/[.\-\s]/g, '').length > 0 || t.files.length),
      marks: (l.estimates || []).map((e) => ({ value: pmgParseMark(e.estimate_value_code), name: e.estimate_value_name, typeName: e.estimate_type_name }))
    }))
  };
}

// Лёгкий запрос, чтобы вход в дневник не сбрасывался из-за бездействия.
async function pmgPing() {
  const res = await fetch(PMG_API + 'journal/user/get-current-user', {
    credentials: 'include', cache: 'no-store',
    headers: { Accept: 'application/json, text/plain, */*', 'X-Requested-With': 'XMLHttpRequest' }
  });
  if (res.status === 401 || res.status === 403 || !/json/i.test(res.headers.get('content-type') || '')) throw new Error('auth');
  if (!res.ok) throw new Error('net');
  return true;
}
