// На сайте дневника: боковая панель + помощь фону с загрузкой данных.
pmgMountDrawer();

// Фон просит загрузить данные отсюда (если ему самому браузер не отдал вход).
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.kind === 'pmg-load') {
    pmgLoadAll(msg.studentId).then((data) => reply({ ok: true, data })).catch((e) => reply({ ok: false, error: e.message }));
    return true;
  }
  if (msg && msg.kind === 'pmg-ping') {
    pmgPing().then(() => reply({ ok: true })).catch((e) => reply({ ok: false, error: e.message }));
    return true;
  }
  if (msg && msg.kind === 'pmg-open') { if (msg.tab) pmg.tab = msg.tab; pmgOpen(); }
  return false;
});

// Мы на сайте и вход есть — хороший момент обновить данные, если они устарели.
if (!/login|auth/i.test(location.pathname)) chrome.runtime.sendMessage({ kind: 'pmg-sync-if-stale' }).catch(() => {});

// Пока вкладка дневника открыта — держим вход живым:
// лёгкий запрос к серверу и «признак активности» для таймера бездействия самого сайта.
setInterval(() => {
  if (pmg.settings && pmg.settings.keepAlive === false) return;
  pmgPing().catch(() => {});
  try {
    const x = Math.round(window.innerWidth / 2), y = Math.round(window.innerHeight / 2);
    document.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, clientX: x, clientY: y }));
    window.dispatchEvent(new Event('focus'));
  } catch (e) { /* не страшно */ }
}, 4 * 60 * 1000);
