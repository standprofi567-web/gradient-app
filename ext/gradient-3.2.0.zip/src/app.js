// Отдельная вкладка помогатора.
pmgMountPage(document.getElementById('app'));
