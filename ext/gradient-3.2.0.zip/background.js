// Фон: сам обновляет данные дневника, даже если сайт не открыт, и присылает уведомления.
importScripts('src/config.js', 'src/calc.js', 'src/api.js', 'src/homework.js', 'src/season.js', 'src/engine.js', 'src/net.js', 'src/game.js', 'src/cloud.js');

const SYNC_EVERY_MIN = 30;
const STALE_MS = 10 * 60 * 1000;
const DIARY_URL = PMG_ORIGIN + '/';
const DEFAULT_SETTINGS = { threshold: 0.55, studentId: null, hwMode: 'assigned', notify: true, keepAlive: true, theme: 'auto', v: 2 };

let syncing = null;

async function getSettings() {
  const { pmg_settings } = await chrome.storage.local.get('pmg_settings');
  let s = { ...DEFAULT_SETTINGS, ...(pmg_settings || {}) };
  if (!pmg_settings || pmg_settings.v !== 2) {
    s = { ...s, threshold: 0.55, notify: true, v: 2 };
    await chrome.storage.local.set({ pmg_settings: s });
  }
  return s;
}

// Загрузка через открытую вкладку дневника — запасной путь, если браузер не отдал cookie фону.
async function loadViaTab(studentId) {
  const tabs = await chrome.tabs.query({ url: PMG_ORIGIN + '/*' });
  for (const tab of tabs) {
    try {
      const r = await chrome.tabs.sendMessage(tab.id, { kind: 'pmg-load', studentId });
      if (r && r.ok) return r.data;
      if (r && r.error) throw new Error(r.error);
    } catch (e) {
      if (e.message === 'auth') throw e;
    }
  }
  throw new Error('auth');
}

async function sync(reason) {
  if (syncing) return syncing;
  syncing = (async () => {
    const settings = await getSettings();
    const { pmg_cache: prev } = await chrome.storage.local.get('pmg_cache');
    let data = null, via = 'background', error = null;
    try {
      data = await pmgLoadAll(settings.studentId);
    } catch (e) {
      try { data = await loadViaTab(settings.studentId); via = 'tab'; } catch (e2) { error = e2.message === 'auth' ? 'auth' : (e2.message || e.message); }
    }
    if (data) {
      await chrome.storage.local.set({ pmg_cache: data, pmg_status: { ok: true, at: Date.now(), via, reason } });
      if (prev && prev.student && prev.student.id === data.student.id && settings.notify) notifyNew(prev, data);
      if (settings.notify) remindReport(data);
    } else {
      await chrome.storage.local.set({ pmg_status: { ok: false, at: Date.now(), error, reason } });
    }
    await updateBadge();
    checkUpdate();
    const cloud = data && settings.cloud;
    if (cloud) await pmgCloudSync().catch((e) => console.warn('cloud', e));
    if (data) await pmgGameRun({ push: true }).then(notifyLevel).catch((e) => console.warn('game', e));
    if (cloud) {
      await pmgCloudPushSnapshot(data).catch((e) => console.warn('snapshot', e));
      await pmgHealthPull().catch(() => {});
    }
    return { ok: !!data, error };
  })();
  try { return await syncing; } finally { syncing = null; }
}

// ---------- Обновления ----------
// Новая версия публикуется строкой в таблице app_release (версия, что нового, ссылка на zip).
function pmgVerNewer(a, b) {
  const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
  return false;
}
async function checkUpdate() {
  try {
    const res = await fetch(PMG_SB_URL + '/rest/v1/app_release?select=version,notes,url&order=created_at.desc&limit=1', { headers: { apikey: PMG_SB_KEY }, cache: 'no-store' });
    if (!res.ok) return;
    const rel = (await res.json())[0];
    const mine = chrome.runtime.getManifest().version;
    if (!rel || !pmgVerNewer(rel.version, mine)) { await chrome.storage.local.remove('pmg_update'); return; }
    const { pmg_update: old } = await chrome.storage.local.get('pmg_update');
    await chrome.storage.local.set({ pmg_update: { version: rel.version, notes: rel.notes, url: rel.url, at: Date.now() } });
    if (!old || old.version !== rel.version) {
      chrome.notifications.create('pmg-update-' + rel.version, {
        type: 'basic', iconUrl: 'icons/icon128.png', priority: 2,
        title: 'Вышел Gradient ' + rel.version, message: (rel.notes ? rel.notes.slice(0, 140) + '\n' : '') + 'Нажми, чтобы скачать'
      });
    }
  } catch (_) { /* нет сети — проверим в следующий раз */ }
}

// Уведомления о новых оценках и новой домашке.
function notifyNew(prev, data) {
  const old = new Set(prev.marks.map((m) => m.id));
  const fresh = data.marks.filter((m) => !old.has(m.id));
  if (fresh.length) {
    const lines = fresh.slice(0, 4).map((m) => m.value + ' — ' + m.subject + (m.typeName ? ' (' + m.typeName.toLowerCase() + ')' : ''));
    chrome.notifications.create('pmg-marks-' + Date.now(), {
      type: 'basic', iconUrl: 'icons/icon128.png', priority: 1,
      title: fresh.length === 1 ? 'Новая оценка' : 'Новые оценки: ' + fresh.length,
      message: lines.join('\n') + (fresh.length > 4 ? '\n…и ещё ' + (fresh.length - 4) : '')
    });
  }
  const oldHw = new Set();
  prev.lessons.forEach((l) => (l.tasks || []).forEach((t, k) => oldHw.add(l.id + ':' + k)));
  const newHw = [];
  data.lessons.forEach((l) => (l.tasks || []).forEach((t, k) => { if (!oldHw.has(l.id + ':' + k)) newHw.push(l.subject); }));
  if (newHw.length) {
    const subj = [...new Set(newHw)];
    chrome.notifications.create('pmg-hw-' + Date.now(), {
      type: 'basic', iconUrl: 'icons/icon128.png', priority: 0,
      title: 'Новая домашка',
      message: subj.slice(0, 5).join(', ') + (subj.length > 5 ? ' и другие' : '')
    });
  }
}

// Значок: сколько не сделано на ближайший учебный день.
async function updateBadge() {
  const s = await chrome.storage.local.get(['pmg_cache', 'pmg_settings', 'pmg_done', 'pmg_hw_due', 'pmg_status']);
  if (!s.pmg_cache) { chrome.action.setBadgeText({ text: '' }); return; }
  const items = pmgBuildHomework(s.pmg_cache.lessons, {
    mode: (s.pmg_settings || {}).hwMode || 'assigned', done: s.pmg_done || {}, overrides: s.pmg_hw_due || {}
  });
  const next = pmgNextDayTodo(items);
  const n = next.items.filter((i) => !i.done).length;
  chrome.action.setBadgeBackgroundColor({ color: '#4C5FD5' });
  chrome.action.setBadgeText({ text: n ? String(n) : '' });
  await chrome.storage.local.set({
    pmg_next: { day: next.day ? next.day.getTime() : null, items: next.items.map((i) => ({ subject: i.subject, text: i.text || (i.files.length ? 'Задание во вложении' : ''), done: i.done })) }
  });
}

// Поддержка входа: раз в 4 минуты тихо обращаемся к дневнику.
async function keepAlive() {
  const settings = await getSettings();
  if (settings.keepAlive === false) return;
  let ok = false, authLost = false;
  try { await pmgPing(); ok = true; } catch (e) { authLost = e.message === 'auth'; }
  if (!ok) {
    // Фону браузер мог не отдать вход — пингуем из открытых вкладок дневника
    const tabs = await chrome.tabs.query({ url: PMG_ORIGIN + '/*' });
    for (const tab of tabs) {
      try {
        const r = await chrome.tabs.sendMessage(tab.id, { kind: 'pmg-ping' });
        if (r && r.ok) { ok = true; break; }
        if (r && r.error === 'auth') authLost = true;
      } catch (e) { /* вкладка спит */ }
    }
  }
  const { pmg_status: st } = await chrome.storage.local.get('pmg_status');
  if (ok && st && !st.ok && st.error === 'auth') sync('relogin');
  if (!ok && authLost && st && st.ok) {
    await chrome.storage.local.set({ pmg_status: { ...st, ok: false, error: 'auth', at: Date.now() } });
    if (settings.notify) chrome.notifications.create('pmg-auth-' + Date.now(), {
      type: 'basic', iconUrl: 'icons/icon128.png', priority: 1,
      title: 'Вход в дневник закончился',
      message: 'Открой дневник и войди ещё раз — Gradient продолжит обновляться сам.'
    });
  }
}

// Под конец четверти (за 2 дня и в последний день) — напомнить про отчёт для родителей.
async function remindReport(data) {
  const d = pmgRevive(data);
  const term = pmgPickPeriod(d.periods, new Date());
  if (!term || term.kind !== 'term') return;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const left = Math.round((term.to - today) / 86400000);
  if (left < 0 || left > 2) return;
  const { pmg_report_reminded: done = {} } = await chrome.storage.local.get('pmg_report_reminded');
  if (done[term.id]) return;
  done[term.id] = Date.now();
  await chrome.storage.local.set({ pmg_report_reminded: done });
  chrome.notifications.create('pmg-report-' + Date.now(), {
    type: 'basic', iconUrl: 'icons/icon128.png', priority: 1,
    title: term.name + ' заканчивается',
    message: 'Сделай отчёт для родителей: итоги четверти одной картинкой.'
  });
}

function openApp(tab) {
  chrome.tabs.create({ url: chrome.runtime.getURL('app.html') + (tab ? '#' + tab : '') });
}

chrome.runtime.onInstalled.addListener(() => {
  scheduleAlarms();
  getSettings().then(() => sync('install'));
});
chrome.runtime.onStartup.addListener(() => {
  scheduleAlarms();
  checkUpdate();
  sync('startup');
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'pmg-sync') sync('timer');
  if (a.name === 'pmg-keepalive') keepAlive();
});
function scheduleAlarms() {
  chrome.alarms.create('pmg-sync', { periodInMinutes: SYNC_EVERY_MIN, delayInMinutes: 1 });
  chrome.alarms.create('pmg-keepalive', { periodInMinutes: 4, delayInMinutes: 4 });
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg) return false;
  if (msg.kind === 'pmg-sync') { sync('manual').then(reply); return true; }
  if (msg.kind === 'pmg-sync-if-stale') {
    chrome.storage.local.get('pmg_status', ({ pmg_status }) => {
      if (!pmg_status || !pmg_status.ok || Date.now() - pmg_status.at > STALE_MS) sync('page');
    });
    return false;
  }
  if (msg.kind === 'pmg-open-app') { openApp(msg.tab); return false; }
  if (msg.kind === 'pmg-update-download') {
    chrome.storage.local.get('pmg_update', ({ pmg_update: u }) => { if (u && u.url) chrome.tabs.create({ url: u.url }); });
    return false;
  }
  if (msg.kind === 'pmg-reload') { setTimeout(() => chrome.runtime.reload(), 150); reply({ ok: true }); return false; }
  if (msg.kind === 'pmg-check-update') { checkUpdate().then(() => reply({ ok: true })); return true; }
  if (msg.kind === 'pmg-game') {
    pmgGameMessage(msg).then(reply, (e) => reply({ ok: false, error: String(e.message || e) }));
    return true;
  }
  return false;
});

let gameTimer = null;
chrome.storage.onChanged.addListener((c) => {
  if (c.pmg_done || c.pmg_hw_due || (c.pmg_settings && !c.pmg_cache)) updateBadge();
  // Галочка домашки — пересчитать очки (с небольшой паузой, чтобы собрать несколько галочек)
  if (c.pmg_done || c.pmg_hw_due) { clearTimeout(gameTimer); gameTimer = setTimeout(() => pmgGameRun({ push: true }), 1500); }
  // Связка с телефоном: свои изменения — на сервер (с паузой)
  if (c.pmg_done || c.pmg_hw_due || c.pmg_logins || c.pmg_actions || c.pmg_quests || c.pmg_wquests || c.pmg_profile || (c.pmg_settings && !c.pmg_cloud_base)) {
    clearTimeout(cloudTimer);
    cloudTimer = setTimeout(async () => { if (await pmgCloudEnabled()) pmgCloudSync().catch(() => {}); }, 4000);
  }
});
let cloudTimer = null;

// Новый уровень, пока панель закрыта — короткое уведомление.
async function notifyLevel(state) {
  if (!state || !state.view) return;
  const { pmg_settings: st, pmg_level_notified: was } = await chrome.storage.local.get(['pmg_settings', 'pmg_level_notified']);
  const lv = state.view.level.level, key = state.view.season.id + ':' + lv;
  if (!was) { await chrome.storage.local.set({ pmg_level_notified: key }); return; }
  if (was === key || (st && st.notify === false)) return;
  const [sid, old] = was.split(':');
  await chrome.storage.local.set({ pmg_level_notified: key });
  if (sid === state.view.season.id && lv > +old) {
    const r = pmgRewardsAt(lv, state.view.season);
    chrome.notifications.create('pmg-level-' + Date.now(), {
      type: 'basic', iconUrl: 'icons/icon128.png', priority: 1,
      title: 'Уровень ' + lv + '!', message: 'Награда: ' + r.map((x) => x.name).join(', ')
    });
  }
}

chrome.notifications.onClicked.addListener((id) => {
  if (id.startsWith('pmg-update')) {
    chrome.storage.local.get('pmg_update', ({ pmg_update: u }) => { if (u && u.url) chrome.tabs.create({ url: u.url }); });
    chrome.notifications.clear(id); return;
  }
  if (id.startsWith('pmg-auth')) { chrome.tabs.create({ url: DIARY_URL }); chrome.notifications.clear(id); return; }
  openApp(id.startsWith('pmg-hw') ? 'homework' : id.startsWith('pmg-report') ? 'report' : id.startsWith('pmg-level') ? 'pass' : 'overview');
  chrome.notifications.clear(id);
});
