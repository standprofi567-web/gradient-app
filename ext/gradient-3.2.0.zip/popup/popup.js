// Всплывающее окно: короткая сводка из последних загруженных данных.
const DIARY = 'https://dnevnik2.petersburgedu.ru/';
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const MONTHS = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

chrome.storage.local.get(['pmg_cache', 'pmg_settings', 'pmg_next', 'pmg_status'], (s) => {
  const theme = (s.pmg_settings && s.pmg_settings.theme) || 'auto';
  if (theme !== 'auto') document.documentElement.dataset.theme = theme;
  const main = document.getElementById('main');
  if (!s.pmg_cache) {
    main.innerHTML = '<div class="card"><p class="muted" style="margin:0">Пока пусто. Открой электронный дневник и войди: дальше Gradient будет обновляться сам каждые 30 минут.</p></div>';
    return;
  }
  const data = pmgRevive(s.pmg_cache);
  const th = (s.pmg_settings && s.pmg_settings.v === 2 && s.pmg_settings.threshold) || 0.55;
  const period = pmgPickPeriod(data.periods, new Date());
  const stats = pmgSubjectStats(data.marks, data.subjects, period, th).filter((x) => x.values.length).sort((a, b) => a.avg - b.avg);
  const marks = data.marks.filter((m) => !period || pmgInPeriod(m, period));
  const avg = pmgAvg(marks.map((m) => m.value));
  document.getElementById('who').textContent = data.student.name + ', ' + data.student.groupName;

  let h = '<div class="card"><div class="avg-row"><div class="avg">' + pmgFmtAvg(avg) + '</div><div class="avg-cap">средний балл' + (period ? ' за ' + esc(period.kind === 'year' ? 'год' : period.name) : '') + '<br>' + marks.length + ' ' + pmgPlural(marks.length, ['оценка', 'оценки', 'оценок']) + '</div></div></div>';
  const next = s.pmg_next;
  if (next && next.day) {
    const d = new Date(next.day);
    const diff = Math.round((d - new Date().setHours(0, 0, 0, 0)) / 86400000);
    h += '<div class="card"><h2>Домашка на ' + (diff === 1 ? 'завтра' : d.getDate() + ' ' + MONTHS[d.getMonth()]) + '</h2><ul class="hw">' +
      next.items.map((i) => '<li class="' + (i.done ? 'done' : '') + '"><b>' + esc(i.subject) + '</b><span>' + esc(i.text) + '</span></li>').join('') + '</ul></div>';
  }
  h += '<div class="card"><h2>Слабые места</h2><ul class="subj">' + stats.slice(0, 5).map((x) =>
    '<li><span>' + esc(x.name) + '</span><b class="m' + Math.max(2, x.rounded) + '">' + pmgFmtAvg(x.avg) + '</b></li>').join('') + '</ul></div>';
  const st = s.pmg_status;
  const t = new Date(data.loadedAt).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
  h += st && !st.ok ? '<p class="st bad">' + (st.error === 'auth' ? 'Нужно войти в дневник. ' : 'Не обновилось. ') + 'Данные от ' + t + '</p>' : '<p class="st">Обновлено ' + t + ', дальше само каждые 30 минут</p>';
  main.innerHTML = h;
});

document.getElementById('app').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('app.html') });
  window.close();
});

document.getElementById('open').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.url && tab.url.startsWith(DIARY)) {
    try { await chrome.tabs.sendMessage(tab.id, { kind: 'pmg-open' }); window.close(); return; } catch (e) {}
    chrome.tabs.reload(tab.id); window.close(); return;
  }
  chrome.tabs.create({ url: DIARY });
  window.close();
});
